import { getCompleted } from '@/lib/api';
import CatalogPage from '@/components/CatalogPage';
export default async function Page({searchParams}) { const data = await getCompleted(searchParams?.page || 1); return <CatalogPage title="Anime Tamat" data={data} />; }
