import { getTopAiring } from '@/lib/api';
import CatalogPage from '@/components/CatalogPage';
export default async function Page({searchParams}) { const data = await getTopAiring(searchParams?.page || 1); return <CatalogPage title="Top Airing" data={data} />; }
