import {getHomeFeed,getTopTen} from '@/lib/api';
import AnimeGrid from '@/components/AnimeGrid';
import Link from 'next/link';
export default async function HomePage(){
 const [data,top]=await Promise.all([getHomeFeed(),getTopTen()]);
 if(!data)return <div className="text-center font-fira text-cyber-magenta mt-20">Gagal terhubung ke API Nanimelaina.</div>;
 const arr=(...values)=>values.find(v=>Array.isArray(v))||[];
 const spotlight=arr(data.spotlight,data.banner,data.featured); const latest=arr(data.latest,data.recent,data.latestReleases); const trending=arr(data.trending,data.popular); const popular=arr(data.popular); const topList=arr(top?.data,top?.results,top?.topTen,top);
 const sections=[['Latest Releases',latest],['Trending Now',trending],['Top 10 Anime',topList],['Popular Anime',popular]];
 return <div className="max-w-7xl mx-auto space-y-12">{spotlight.length>0&&<section className="rounded-xl border border-cyber-magenta/30 bg-gradient-to-r from-cyber-magenta/10 to-cyber-cyan/10 p-6"><p className="text-xs text-cyber-cyan font-fira mb-2">FEATURED / SPOTLIGHT</p><AnimeGrid animeList={spotlight.slice(0,3)}/></section>}{sections.map(([title,list])=>list.length>0&&<section key={title}><h2 className="font-orbitron text-xl md:text-2xl text-cyber-cyan mb-6 uppercase tracking-wider border-l-4 border-cyber-magenta pl-3">{title}</h2><AnimeGrid animeList={list}/></section>)}<section className="flex flex-wrap gap-3">{[['Random Anime','/random'],['Trending','/trending'],['Popular','/popular'],['Top Airing','/top-airing'],['Upcoming','/upcoming'],['Completed','/completed'],['TV Series','/tvseries'],['Movies','/movies'],['Weekly Schedule','/weekly-schedule']].map(([t,u])=><Link key={u} href={u} className="border border-cyber-cyan/30 rounded px-4 py-3 text-sm text-cyber-cyan hover:bg-cyber-cyan/10">{t} →</Link>)}</section></div>;
}
