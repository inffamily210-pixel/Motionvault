import { getPopular } from '@/lib/api';
import CatalogPage from '@/components/CatalogPage';
export default async function Page({searchParams}) { const data = await getPopular(searchParams?.page || 1); return <CatalogPage title="Anime Populer" data={data} />; }
