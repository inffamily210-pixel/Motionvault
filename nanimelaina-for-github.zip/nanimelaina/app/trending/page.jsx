import { getTrending } from '@/lib/api';
import CatalogPage from '@/components/CatalogPage';
export default async function Page({searchParams}) { const data = await getTrending(searchParams?.page || 1); return <CatalogPage title="Trending Anime" data={data} />; }
