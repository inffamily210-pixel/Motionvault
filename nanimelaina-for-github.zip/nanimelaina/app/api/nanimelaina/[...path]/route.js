const UPSTREAM='https://v1312.nanimelaina.web.id/api';
const ALLOWED=[
 /^nanimelaina\/(home|top-ten|random|anime\/[\w.-]+|episodes\/[\w.-]+|servers\/[\w.-]+|stream\/[\w.-]+|play\/[\w.-]+|hls\/manifest\/[\w.-]+|subtitle\/translate|subtitle\/stats|tmdb-thumbnails|skip-times|search|az-list|trending|popular|top-airing|upcoming|completed|tvseries|movies|genres|genre\/[\w%.-]+|producer\/[\w%.-]+|schedule|schedule\/weekly|schedule\/[\w.-]+)$/,
 /^nanimelaina\/(cache\/status|cache\/start|local-mp4)$/,
 /^subtitle\/filter-rules$/
];
async function proxy(req,{params}){
 const parts=await params.path; const path=Array.isArray(parts)?parts.join('/') : String(parts||'');
 if(!ALLOWED.some(r=>r.test(path))) return Response.json({error:'Endpoint tidak diizinkan'}, {status:404});
 if(path==='subtitle/filter-rules' && !['GET','POST'].includes(req.method)) return Response.json({error:'Method tidak diizinkan'}, {status:405});
 if(path!=='subtitle/filter-rules' && req.method!=='GET') return Response.json({error:'Method tidak diizinkan'}, {status:405});
 const incoming=new URL(req.url); const target=new URL(`${UPSTREAM}/${path}`);
 for(const [k,v] of incoming.searchParams) if(['q','page','date','day','letter','ep','server','type','url','lang','title','anilistId','malId','episode','id'].includes(k) && v.length<=2048) target.searchParams.set(k,v);
 try{
  const init={method:req.method,headers:{Accept:'application/json'}};
  if(req.method==='POST'){init.headers['Content-Type']='application/json';init.body=await req.text();}
  const upstream=await fetch(target,{...init,signal:AbortSignal.timeout(20000)});
  const body=await upstream.arrayBuffer();
  return new Response(body,{status:upstream.status,headers:{'Content-Type':upstream.headers.get('content-type')||'application/json','Cache-Control':'no-store'}});
 }catch(e){return Response.json({error:'Nanimelaina API sedang tidak tersedia'},{status:502});}
}
export const GET=proxy; export const POST=proxy;
