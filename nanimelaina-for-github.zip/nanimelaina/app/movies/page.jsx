import { getMovies } from '@/lib/api';
import CatalogPage from '@/components/CatalogPage';
export default async function Page({searchParams}) { const data = await getMovies(searchParams?.page || 1); return <CatalogPage title="Anime Movies" data={data} />; }
