import { getProducer } from '@/lib/api';
import CatalogPage from '@/components/CatalogPage';
export default async function Page({params,searchParams}) { const data=await getProducer(params.producer,searchParams?.page||1); return <CatalogPage title={`Studio: ${decodeURIComponent(params.producer)}`} data={data}/>; }
