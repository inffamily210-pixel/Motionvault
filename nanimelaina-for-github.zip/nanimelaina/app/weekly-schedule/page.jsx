import { getWeeklySchedule } from '@/lib/api';
import CatalogPage from '@/components/CatalogPage';
export default async function Page() { const data = await getWeeklySchedule(); return <CatalogPage title="Jadwal Anime Mingguan" data={data} description="Jadwal rilis Senin sampai Minggu." />; }
