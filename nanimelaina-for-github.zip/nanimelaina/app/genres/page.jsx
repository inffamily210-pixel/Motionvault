import { getGenres } from '@/lib/api';

export default async function GenresPage() {
  const data = await getGenres();
  const genres = data?.data || data?.genres || [];

  return (
    <div className="max-w-7xl mx-auto">
      <h2 className="font-orbitron text-2xl text-cyber-cyan border-l-4 border-cyber-magenta pl-3 mb-8">Katalog Genre</h2>
      
      {genres.length > 0 ? (
        <div className="flex flex-wrap gap-3 md:gap-4">
          {genres.map((genre) => (
            <a 
              key={genre.name || genre} 
              href={`/genre/${encodeURIComponent(genre.name || genre)}`} 
              className="bg-cyber-dark border border-cyber-cyan/30 text-white font-fira text-sm px-4 py-2 rounded hover:bg-cyber-cyan/10 hover:border-cyber-cyan hover:shadow-neon-cyan transition-all"
            >
              {genre}
            </a>
          ))}
        </div>
      ) : (
        <p className="font-fira text-cyber-cyan/50">Gagal memuat daftar genre.</p>
      )}
    </div>
  );
}
