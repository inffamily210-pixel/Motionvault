import { getTvSeries } from '@/lib/api';
import CatalogPage from '@/components/CatalogPage';
export default async function Page({searchParams}) { const data = await getTvSeries(searchParams?.page || 1); return <CatalogPage title="TV Series" data={data} />; }
