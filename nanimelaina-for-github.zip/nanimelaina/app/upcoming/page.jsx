import { getUpcoming } from '@/lib/api';
import CatalogPage from '@/components/CatalogPage';
export default async function Page({searchParams}) { const data = await getUpcoming(searchParams?.page || 1); return <CatalogPage title="Anime Mendatang" data={data} />; }
