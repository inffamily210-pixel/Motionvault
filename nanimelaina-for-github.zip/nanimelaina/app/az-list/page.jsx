import { getAzList } from '@/lib/api';
import AnimeGrid from '@/components/AnimeGrid';

export default async function AzListPage({ searchParams }) {
  const letter = searchParams.letter || 'ALL';
  const data = await getAzList(letter);
  const list = data?.data || data?.results || [];

  const alphabet = ['ALL', '0-9', ...Array.from({length: 26}, (_, i) => String.fromCharCode(65 + i))];

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      <div className="bg-cyber-gray/30 p-4 rounded-lg border border-cyber-magenta/20 overflow-x-auto custom-scrollbar pb-2">
        <div className="flex gap-2 min-w-max">
          {alphabet.map(l => (
            <a 
              key={l}
              href={`?letter=${l}`}
              className={`font-fira text-xs px-3 py-1.5 rounded border transition-all ${
                letter === l 
                ? 'bg-cyber-magenta text-white border-cyber-magenta shadow-[0_0_8px_rgba(255,0,60,0.5)]' 
                : 'bg-cyber-dark text-gray-400 border-cyber-cyan/20 hover:border-cyber-cyan hover:text-cyber-cyan'
              }`}
            >
              {l}
            </a>
          ))}
        </div>
      </div>

      <AnimeGrid animeList={list} emptyMessage={`Tidak ada anime yang berawalan dari '${letter}'.`} />
    </div>
  );
}
