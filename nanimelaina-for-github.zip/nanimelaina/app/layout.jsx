import { Orbitron, Fira_Code } from 'next/font/google';
import Link from 'next/link';
import './globals.css';

const orbitron = Orbitron({ subsets: ['latin'], variable: '--font-orbitron' });
const firaCode = Fira_Code({ subsets: ['latin'], variable: '--font-fira-code' });

export const metadata = {
  title: 'Nanimelaina Stream',
  description: 'M3U8 Decrypted Stream Proxy Frontend',
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body className={`${orbitron.variable} ${firaCode.variable} bg-cyber-dark text-white min-h-screen flex flex-col`}>
        <nav className="border-b border-cyber-magenta/30 bg-cyber-gray/80 p-4 backdrop-blur-md sticky top-0 z-50 flex flex-wrap items-center justify-between gap-4">
          <Link href="/">
            <h1 className="font-orbitron text-2xl text-cyber-cyan drop-shadow-[0_0_8px_rgba(0,240,255,0.8)] hover:text-white transition-colors">
              NANI<span className="text-cyber-magenta">MELAINA</span>
            </h1>
          </Link>
          <div className="flex gap-6 font-fira text-sm overflow-x-auto custom-scrollbar pb-1">
            <Link href="/search" className="hover:text-cyber-cyan transition-colors whitespace-nowrap">Search</Link>
            <Link href="/trending" className="hover:text-cyber-cyan transition-colors whitespace-nowrap">Trending</Link>
            <Link href="/popular" className="hover:text-cyber-cyan transition-colors whitespace-nowrap">Popular</Link>
            <Link href="/top-airing" className="hover:text-cyber-cyan transition-colors whitespace-nowrap">Airing</Link>
            <Link href="/movies" className="hover:text-cyber-cyan transition-colors whitespace-nowrap">Movies</Link>
            <Link href="/weekly-schedule" className="hover:text-cyber-cyan transition-colors whitespace-nowrap">Weekly</Link>
            <Link href="/subtitles" className="hover:text-cyber-cyan transition-colors whitespace-nowrap">Subtitle</Link>
            <Link href="/api-tools" className="hover:text-cyber-cyan transition-colors whitespace-nowrap">API Tools</Link>
            <Link href="/schedule" className="hover:text-cyber-cyan transition-colors whitespace-nowrap">Schedule</Link>
            <Link href="/genres" className="hover:text-cyber-cyan transition-colors whitespace-nowrap">Genres</Link>
            <Link href="/az-list" className="hover:text-cyber-cyan transition-colors whitespace-nowrap">A-Z List</Link>
          </div>
        </nav>
        <main className="p-4 md:p-6 flex-grow">
          {children}
        </main>
        <footer className="border-t border-cyber-cyan/20 bg-cyber-gray/50 p-6 text-center font-fira text-xs text-gray-500 mt-10">
          <p>Powered by Nanimelaina API • UI with Next.js App Router</p>
        </footer>
      </body>
    </html>
  );
}
