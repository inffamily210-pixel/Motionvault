import { getSchedule } from '@/lib/api';
import AnimeGrid from '@/components/AnimeGrid';

export default async function SchedulePage() {
  const data = await getSchedule('today');
  const scheduleList = data?.data || data?.schedule || [];

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      <div className="flex items-center justify-between mb-8">
         <h2 className="font-orbitron text-2xl text-cyber-cyan border-l-4 border-cyber-magenta pl-3">Jadwal Rilis Hari Ini</h2>
         <span className="font-fira text-xs bg-cyber-magenta/20 text-cyber-magenta px-3 py-1 rounded border border-cyber-magenta/50">ONGOING</span>
      </div>
      
      <AnimeGrid animeList={scheduleList} emptyMessage="Tidak ada jadwal rilis hari ini." />
    </div>
  );
}
