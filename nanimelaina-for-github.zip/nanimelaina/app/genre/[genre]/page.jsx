import { getGenre } from '@/lib/api';
import CatalogPage from '@/components/CatalogPage';
export default async function Page({params,searchParams}) { const data=await getGenre(params.genre,searchParams?.page||1); return <CatalogPage title={`Genre: ${decodeURIComponent(params.genre)}`} data={data}/>; }
