# Nanimelaina API Integration

Frontend Next.js 14 app integrated with `https://v1312.nanimelaina.web.id`.

## Implemented
- Discovery: home feed, spotlight, trending, popular, top-ten, random page.
- Catalog: top-airing, upcoming, completed, TV series, movies, genres, genre, producer/studio, A-Z.
- Search: query, page, genre, format, season, year, status filters.
- Detail/player: detail metadata, episode list, server list, sub/dub selector, embedded native player, stream response.
- Extras: TMDB episode thumbnails, AniSkip skip timestamps, next-episode countdown.
- Schedule: daily and weekly views.
- Subtitle: ASS/SRT translator UI, subtitle cache stats, filter rules read helper and POST helper.
- Offline: cache status, trigger background MP4 cache, local MP4 link.
- Same-origin allowlisted API proxy at `/api/nanimelaina/[...path]` for browser-side subtitle/cache requests.

## Run
```bash
npm install
npm run dev
```

## Notes
- The `MotionVault-Nanimelaina-Integrated.zip` archive is a separate Alight Motion/CapCut preset product and is intentionally not merged into this anime frontend.
- API response schemas can vary by endpoint. The UI normalizes common `data`, `results`, `episodes`, `anime`, and `items` response shapes; verify against live API payloads before production.
- The cache-start endpoint triggers remote server work. Use it only when the user explicitly requests offline caching.
