import Link from 'next/link';
export default function AnimeGrid({animeList,emptyMessage='Tidak ada data.'}) {
 if(!Array.isArray(animeList)||animeList.length===0)return <p className="font-fira text-cyber-cyan/50 py-10 text-center">{emptyMessage}</p>;
 return <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 md:gap-6">{animeList.map((anime,index)=>{
  const id=anime.id||anime.anilistId||anime.anilist_id||anime.slug||anime.malId||index;
  const title=typeof anime.title==='string'?anime.title:anime.title?.english||anime.title?.romaji||anime.name||'Untitled Anime';
  const poster=anime.poster||anime.image||anime.cover||anime.coverImage?.large||anime.posterImage?.large||'https://placehold.co/300x420/101018/00f0ff?text=No+Image';
  return <Link href={`/anime/${id}`} key={id} className="group relative block overflow-hidden rounded-lg bg-cyber-gray border border-cyber-cyan/20 hover:border-cyber-cyan hover:shadow-neon-cyan transition-all duration-300"><img src={poster} alt={title} loading="lazy" className="w-full h-56 md:h-72 object-cover opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500"/><div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-cyber-dark via-cyber-dark/80 to-transparent p-3 pt-12"><h3 className="font-orbitron text-xs md:text-sm text-white line-clamp-2 leading-tight">{title}</h3>{(anime.format||anime.episode||anime.rating)&&<p className="font-fira text-[10px] md:text-xs text-cyber-cyan mt-1 truncate">{anime.format||'TV'} {anime.episode?`• Ep ${anime.episode}`:''} {anime.rating?`• ★${anime.rating}`:''}</p>}</div></Link>;
 })}</div>;
}
