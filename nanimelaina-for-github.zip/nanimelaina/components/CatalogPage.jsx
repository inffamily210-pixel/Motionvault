import AnimeGrid from './AnimeGrid';
export default function CatalogPage({title,data,description}) {
  const list = Array.isArray(data) ? data : data?.data || data?.results || data?.anime || data?.items || [];
  return <div className="max-w-7xl mx-auto space-y-6"><header><h1 className="font-orbitron text-2xl md:text-3xl text-cyber-cyan border-l-4 border-cyber-magenta pl-3">{title}</h1>{description && <p className="font-fira text-xs text-gray-400 mt-3">{description}</p>}</header><AnimeGrid animeList={list} emptyMessage="Data anime belum tersedia atau API sedang tidak merespons." /></div>;
}
